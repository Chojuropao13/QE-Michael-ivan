package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class PUTNEGATIVE {

    public static String url = "https://jsonplaceholder.typicode.com/posts/1 ";

    @Step("I can't change the data with method PUT")
    public String iCanTChangeTheDataWithMethodPUT() {
        return url;

    }

    @Step("I can't set PUT Http request")
    public void iCanTSetPUTHttpRequest() {
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", "sunt aut facere repellat provident occaecati excepturi optio reprehenderit");
        requestBody.put("body", "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto");
        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toString()).put(iCanTChangeTheDataWithMethodPUT());
    }

    @Step("give me Http code {int}")
    public void giveDifferentMeHttpCode() {
        restAssuredThat(response -> response.statusCode(404));
    }
}
