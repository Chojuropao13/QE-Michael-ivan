package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DELNEG {

    public static String url = "https://jsonplaceholder.typicode.com/posts";

    @Step("I set can't DELETE data")
    public String iSetCanTDELETEData() {
        return url;
    }

    @Step("I can't set DELETE Http Request")
    public void iCanTSetDELETEHttpRequest() {
        SerenityRest.given().delete(iSetCanTDELETEData());
    }

    @Step("Oops Sorry Http code {int}")
    public void oopsSorryHttpCode() {
        restAssuredThat(response -> response.statusCode(404));
    }
}
