package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.Out;

public class OutSteps {

    @Steps
    Out out;

    @Given("a user on login page")
    public void aUserOnLoginPage() {
        out.aUserOnLoginPage();
    }

    @When("a user input valid username")
    public void aUserInputValidUsername () throws InterruptedException {
        out.aUserInputValidUsername("standard_user");
    }

    @And("a user input valid password")
    public void aUserInputValidPassword () throws InterruptedException {
        out.aUserInputValidPassword("secret_sauce");
    }

    @And("user click buutton")
    public void UserClickBuutton () throws InterruptedException {
        out.UserClickBuutton();
    }

    @And("look at the menu log out")
    public void LookAtTheMenuLogOut() throws InterruptedException {
        out.LookAtTheMenuLogOut();
    }


    @Then("user click to logout")
    public void UserClickToLogOut () throws InterruptedException {
        out.UserClickToLogOut();
    }
}
