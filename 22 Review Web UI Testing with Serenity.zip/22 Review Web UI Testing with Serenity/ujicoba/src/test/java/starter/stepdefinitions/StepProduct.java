package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.NegativeProduct;
import starter.pages.ProductPage;

public class StepProduct {
    @Steps
    ProductPage productPage;
    NegativeProduct negativeProduct;

    @Given("as a user on homepage")
    public void UserOnHomePage() throws InterruptedException {
        productPage.UserOnHomePage();
    }

    @When("user input username")
    public void userInputUsername() throws InterruptedException{
        productPage.userInputUsername("standard_user");
    }

    @And("user input password")
    public void userInputPassword() throws InterruptedException {
        productPage.userInputPassword("secret_sauce");
    }


    @And("click button")
    public void clickButton() throws InterruptedException {
        productPage.clickButton();
    }

    @And("user click addd to chart")
    public void ClickAddToChart() throws InterruptedException {
        productPage.ClickAddToChart();
    }

    @Then("item goes to bucket")
    public void GoesToBucket() throws InterruptedException {
        productPage.GoesToBucket();
    }

    @Given("user on home page")
    public void userOnHomePage() throws InterruptedException {
        negativeProduct.userOnHomePage();
    }

    @When("a user input username")
    public void aUserInputUsername() throws InterruptedException {
        negativeProduct.aUserInputUsername("standard_user");
    }

    @And("a user input password")
    public void aUserInputPassword() throws InterruptedException {
        negativeProduct.aUserInputPassword("secret_sauce");
    }

    @And("click buttton")
    public void clickButtton() throws InterruptedException {
        negativeProduct.clickButtton();
    }

    @And("user click add to chart")
    public void userClickAddToChart()throws InterruptedException {
        negativeProduct.userClickAddToChart();
    }
}