package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class ProductPage extends PageObject {
    private By usernameField() {
        return By.id("user-name");
    }
    private By passwordField() {
        return By.id("password");
    }

    private By loginButon() {
        return By.id("login-button");
    }

    private By products() {
        return By.id("add-to-cart-sauce-labs-backpack");
    }

    private By buckets() { return By.id("shopping_cart_container"); }

    @Step
    public void UserOnHomePage() throws InterruptedException {
        open();
        $(loginButon()).shouldBeVisible();
    }

    @Step
    public void userInputUsername(String username) throws InterruptedException {
        open();
        $(usernameField()).type(username);
        Thread.sleep(1000);
    }

    @Step
    public void userInputPassword(String password) throws InterruptedException {
        $(passwordField()).type(password);
        Thread.sleep(1000);
    }

    @Step
    public void clickButton() throws InterruptedException {
        $(loginButon()).click();
        Thread.sleep(1000);
    }

    @Step
    public void ClickAddToChart() throws InterruptedException {
        $(products()).click();
        Thread.sleep(1000);
    }

    @Step
    public void GoesToBucket() throws InterruptedException {
        $(buckets()).click();
        Thread.sleep(1000);
    }
}
