package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class NegativeProduct extends PageObject {
    private By usernameField() {
        return By.id("user-name");
    }
    private By passwordField() {
        return By.id("password");
    }

    private By loginButon() {
        return By.id("login-button");
    }

    private By products() {
        return By.id("MOBILE LEGEND");
    }




    @Step
    public void userOnHomePage() throws InterruptedException {
        open();
        $(loginButon()).shouldBeVisible();
    }

    @Step
    public void aUserInputUsername(String username) throws InterruptedException {
        open();
        $(usernameField()).type(username);
        Thread.sleep(1500);
    }

    @Step
    public void aUserInputPassword(String password) throws InterruptedException {
        $(passwordField()).type(password);
        Thread.sleep(1500);
    }

    @Step
    public void clickButtton() throws InterruptedException {
        $(loginButon()).click();
        Thread.sleep(1500);
    }

    @Step
    public void userClickAddToChart()throws InterruptedException {
        $(products()).click();
        Thread.sleep(1500);
    }
}
