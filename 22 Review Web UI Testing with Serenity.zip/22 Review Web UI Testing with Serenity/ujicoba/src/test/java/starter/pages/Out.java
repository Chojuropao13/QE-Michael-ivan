package starter.pages;


import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Out extends PageObject {

    private By usernameField() {
        return By.id("user-name");
    }

    private By passwordField() {
        return By.id("password");
    }

    private By loginButon() {
        return By.id("login-button");
    }

    private  By menu() { return By.id("react-burger-menu-btn");}

    private By LogOutField() {
        return By.id("logout_sidebar_link");
    }

    @Step
    public void aUserOnLoginPage() {
        open();
        $(loginButon()).shouldBeVisible();
    }

    @Step
    public void aUserInputValidUsername (String username) throws InterruptedException {
        open();
        $(usernameField()).type(username);
        Thread.sleep(1500);
    }

    @Step
    public void aUserInputValidPassword (String password) throws InterruptedException {
        $(passwordField()).type(password);
        Thread.sleep(1500);

    }

    @Step
    public void UserClickBuutton () throws InterruptedException {
        $(loginButon()).click();
        Thread.sleep(1500);
    }

    @Step
    public void LookAtTheMenuLogOut() throws InterruptedException {
        $(menu()).click();
        Thread.sleep(1500);
    }
    @Step
    public void UserClickToLogOut () throws InterruptedException {
        $(LogOutField()).click();
        Thread.sleep(1500);
    }


}
